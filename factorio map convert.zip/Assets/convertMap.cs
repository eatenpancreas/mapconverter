using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;

public class convertMap : MonoBehaviour {
    public int HardLimit;
    public TextMeshProUGUI Iterations;
    public Gradient mapGradient;

    // ---------------- Core ------------------- //

    void Start() {
        StartCoroutine(SlowProcess());

    }

    private IEnumerator<WaitForSeconds> SlowProcess() {
        Texture2D texture = GetTexture();

        Texture2D output = CreateOutputTexture(texture);

        Vector2Int start = GetStartingPosition(texture);

        int hardlimit = 0;

        // Data map
        Map map = new Map(texture.GetPixels(), start, texture.width, texture.height);

        ApplyTexture(output);

        // Main loop
        while (map.checkPoints.Count > 0 && hardlimit < HardLimit) {
            GridPoint checking = map.checkPoints[0];
            map.checkedPositions[checking.x, checking.y] = true;

            foreach (var neighbour in GetNeighbourPoints(checking, map)) {
                //map.outputPixels[neighbour.Pos1D(texture.width)] = new Color(neighbour.value / 50f, 0, neighbour.value / 50f);
                SetQueuePosition(map.checkPoints, neighbour);
            }

            map.checkPoints.RemoveAt(0);
            map.donePoints.Add(checking);
            hardlimit++;

            if (hardlimit % 10000 == 0) {
                IterationsUIUpdate(hardlimit);
                yield return new WaitForSeconds(0.001f);
            }
        }

        // gives all points the right color
        foreach (var point in map.donePoints) {
            if (point == null) { continue; }
            float normalisedValue = point.value / map.maxValue;
            Color c = Color.black;
            if (point.value < 9999999999) {
                c = mapGradient.Evaluate(normalisedValue);
            }
            map.outputPixels[point.Pos1D(map.width)] = c;


        }

        output.SetPixels(map.outputPixels);
        output.SetPixel(start.x, start.y, Color.green);
        IterationsUIUpdate(hardlimit);

        ApplyTexture(output);
        SaveOutput(output);
        yield return null;
    }
    

    void FastProcess () {
        Texture2D texture = GetTexture();

        Texture2D output = CreateOutputTexture(texture);

        Vector2Int start = GetStartingPosition(texture);

        int hardlimit = 0;

        // Data map
        Map map = new Map(texture.GetPixels(), start, texture.width, texture.height);

        // Main loop
        while (map.checkPoints.Count > 0 && hardlimit < HardLimit) {
            GridPoint checking = map.checkPoints[0];
            map.checkedPositions[checking.x, checking.y] = true;

            foreach (var neighbour in GetNeighbourPoints(checking, map)) {
                //map.outputPixels[neighbour.Pos1D(texture.width)] = new Color(neighbour.value / 50f, 0, neighbour.value / 50f);
                SetQueuePosition(map.checkPoints, neighbour);
            }

            map.checkPoints.RemoveAt(0);
            map.donePoints.Add(checking);
            hardlimit++;
        }

        // gives all points the right color
        foreach (var point in map.donePoints) {
            if (point == null) { continue; }
            float normalisedValue = point.value / map.maxValue;
            Color c = Color.black;
            if (point.value < 9999999999) {
                c = mapGradient.Evaluate(normalisedValue);
            }
            map.outputPixels[point.Pos1D(map.width)] = c;
        }

        output.SetPixels(map.outputPixels);
        output.SetPixel(start.x, start.y, Color.green);
        IterationsUIUpdate(hardlimit);

        ApplyTexture(output);
        SaveOutput(output);
    }

    // ------------- Modules ----------------- //

    void SaveOutput(Texture2D output) {
        byte[] pngFile = output.EncodeToPNG();
        File.WriteAllBytes(Application.dataPath + "/Output/output.png", pngFile);
    }

    class Map {
        public int width;
        public int height;

        public float maxValue;

        public Color[] pixels;
        public Color[] outputPixels;

        public List<GridPoint> checkPoints;
        public List<GridPoint> donePoints;
        public bool[,] checkedPositions;
        public GridPoint[,] pointMap;

        public Map(Color[] pixels, Vector2Int start, int width, int height) {
            this.width = width;
            this.height = height;

            this.pixels = pixels;
            outputPixels = new Color[pixels.Length];

            checkPoints = new List<GridPoint>();
            donePoints = new List<GridPoint>();
            checkedPositions = new bool[width, height];
            pointMap = new GridPoint[width, height];

            // Add starting point
            GridPoint s = new GridPoint(start.x, start.y);
            checkPoints.Add(s);
            pointMap[start.x, start.y] = s;
        }
    }

    void SetQueuePosition(List<GridPoint> checkPoints, GridPoint neighbour) {

        for (int i = 0; i < checkPoints.Count; i++) {
            if (neighbour.x == checkPoints[i].x && neighbour.y == checkPoints[i].y) {
                return;
            }
            if (neighbour.value < checkPoints[i].value) {
                checkPoints.Insert(i, neighbour);
                return;
            }
        }

        // happens if it has less value than any other
        checkPoints.Add(neighbour);
    }

    void IterationsUIUpdate (int iterations) {
        Iterations.text = "Iterations: " + iterations;
    }

    List<GridPoint> GetNeighbourPoints(GridPoint currentPoint, Map map) {
        List<GridPoint> neighbourPoints = new List<GridPoint>();

        // LEFT
        if (currentPoint.x > 0 && !map.checkedPositions[currentPoint.x - 1, currentPoint.y]) {
            neighbourPoints.Add(NewNeighbour(currentPoint.x - 1, currentPoint.y, currentPoint.value, map));
        }
        // RIGHT
        if (currentPoint.x < map.width - 1 && !map.checkedPositions[currentPoint.x + 1, currentPoint.y]) {
            neighbourPoints.Add(NewNeighbour(currentPoint.x + 1, currentPoint.y, currentPoint.value, map));
        }
        // DOWN
        if (currentPoint.y > 0 && !map.checkedPositions[currentPoint.x, currentPoint.y - 1]) {
            neighbourPoints.Add(NewNeighbour(currentPoint.x, currentPoint.y - 1, currentPoint.value, map));
        }
        // UP
        if (currentPoint.y < map.width - 1 && !map.checkedPositions[currentPoint.x, currentPoint.y + 1]) {
            neighbourPoints.Add(NewNeighbour(currentPoint.x, currentPoint.y + 1, currentPoint.value, map));
        }


        return neighbourPoints;
    }

    GridPoint NewNeighbour(int x, int y, float currentPointValue, Map map) {
        if (map.pointMap[x,y] == null) {
            // creates newly found spot
            GridPoint point = new GridPoint(x, y);
            Color c = map.pixels[point.Pos1D(map.width)];
            point.value = currentPointValue + GetSpeedAt(c);

            if (point.value < 9999999999) {
                map.maxValue = Mathf.Max(point.value, map.maxValue);
            }


            return point;
        } else {
            // updates value of already found spot
            GridPoint point = map.pointMap[x,y];
            Color c = map.pixels[point.Pos1D(map.width)];
            point.value = Mathf.Min(point.value, currentPointValue + GetSpeedAt(c));

            return point;
        }
    }

    class GridPoint {
        public int x;
        public int y;
        public Vector2Int pos;
        public float value;

        public int Pos1D(int totalWidth) {
            return x + y * totalWidth;
        }

        public GridPoint(int x, int y, float value = 0) {
            this.x = x;
            this.y = y;
            this.value = value;

            pos = new Vector2Int(x, y);
        }
    }


    float GetSpeedAt(Color col) {
        string hash = ColorUtility.ToHtmlStringRGB(col);

        switch (hash) {
            case "FFFFFF": // Rails
                return 0.100f;
            case "FFFF96": // Reinforced Concrete
                return 0.666f;
            case "FFDA47": // Concrete
                return 0.714f;
            case "FF9700": // Regular Ground
                return 1.0f;
            case "7F0000": // Minor Obstruction
                return 5.0f;
            case "FF0000": // Obstruction
                return 9999999999.9f;
            case "000000": // Outside
                return 9999999999.9f;
            case "2F3B7C": // Sea
                return 9999999999.9f;
            default:
                return 9999999999.9f;
        }
    }

    Vector2Int GetStartingPosition(Texture2D texture) {
        Color[] pixels = texture.GetPixels();
        for (int i = 0; i < pixels.Length; i++) {
            if (pixels[i] == Color.green) {
                int y = (int)Mathf.Floor(i / texture.width);
                int x = i - y * texture.width;

                Debug.Log("Found start at (" + x + "x, " + y + "y).");
                return new Vector2Int(x, y);
            }
        }
        Debug.Log("Could not find start! Defaulting to (1x ,1y).");
        return Vector2Int.one;
    }

    Texture2D CreateOutputTexture(Texture2D source) {
        Texture2D output = new Texture2D(source.width, source.height);

        output.filterMode = FilterMode.Point;

        return output;
    }

    Texture2D GetTexture() {
        Debug.Log("Fetching sprite...");
        return GetComponent<SpriteRenderer>().sprite.texture;
    }

    void UpdateTexture(Texture2D texture) {
        texture.Apply();
    }

    void ApplyTexture(Texture2D texture) {
        texture.Apply();
        Debug.Log("Applying final texture...");
        Sprite s = Sprite.Create(texture, new Rect(0.0f, 0.0f, texture.width, texture.height), Vector2.one / 2);
        GetComponent<SpriteRenderer>().sprite = s;

        float scale = 32f / texture.height * 31f;
        transform.localScale = new Vector3(scale, scale, 1);
    }
}
